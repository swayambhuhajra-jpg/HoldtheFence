#!/usr/bin/env bash
# Hold the Fence - build a test APK on macOS / Linux.
# Needs: Node.js 22 LTS and Android Studio (opened once so it installs the Android SDK).
set -e
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js is not installed. Get the LTS version from https://nodejs.org"; exit 1; }
if [ -z "$ANDROID_HOME" ]; then
  if [ -d "$HOME/Library/Android/sdk" ]; then ANDROID_HOME="$HOME/Library/Android/sdk"; else ANDROID_HOME="$HOME/Android/Sdk"; fi
fi
[ -d "$ANDROID_HOME" ] || { echo "Android SDK not found at $ANDROID_HOME. Open Android Studio once to install it."; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > android/local.properties
npm install
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleDebug)
cp android/app/build/outputs/apk/debug/app-debug.apk HoldTheFence-debug.apk
echo "Done: HoldTheFence-debug.apk is in this folder. Copy it to an Android phone to install."
