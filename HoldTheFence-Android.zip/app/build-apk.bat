@echo off
REM Hold the Fence - build a test APK on Windows.
REM Needs: Node.js 22 LTS and Android Studio (opened once so it installs the Android SDK).
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js is not installed. Get the LTS version from https://nodejs.org & pause & exit /b 1)
if not defined JAVA_HOME if exist "C:\Program Files\Android\Android Studio\jbr" set "JAVA_HOME=C:\Program Files\Android\Android Studio\jbr"
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%" (echo Android SDK not found at %ANDROID_HOME%. Open Android Studio once to install it. & pause & exit /b 1)
set "SDKDIR=%ANDROID_HOME:\=\\%"
echo sdk.dir=%SDKDIR%> android\local.properties
call npm install || goto :fail
call npx cap sync android || goto :fail
cd android
call gradlew.bat assembleDebug || goto :fail
cd ..
copy /y android\app\build\outputs\apk\debug\app-debug.apk HoldTheFence-debug.apk >nul
echo.
echo Done: HoldTheFence-debug.apk is in this folder. Copy it to an Android phone to install.
pause
exit /b 0
:fail
echo Build failed. Scroll up for the first error.
pause
exit /b 1
