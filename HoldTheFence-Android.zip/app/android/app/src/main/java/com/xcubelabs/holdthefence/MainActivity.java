package com.xcubelabs.holdthefence;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
